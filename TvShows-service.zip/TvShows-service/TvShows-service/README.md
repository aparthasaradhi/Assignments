# FluxFlix (Generated Project)

This archive contains a scaffold for the FluxFlix reactive backend assignment (Spring WebFlux + R2DBC + Reactive MongoDB).

Notes:
- Some implementations are simplified for brevity (ingest streaming should be hardened for production).
- Configure `src/main/resources/application.yml` for your DB credentials.

Build:
- mvn clean package
- mvn spring-boot:run
