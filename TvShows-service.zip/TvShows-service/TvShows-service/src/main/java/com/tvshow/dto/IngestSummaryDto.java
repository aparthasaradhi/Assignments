package com.tvshow.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class IngestSummaryDto {

    private long totalRecordsProcessed;
    private long successCount;
    private long failureCount;

    @JsonCreator
    public IngestSummaryDto(
            @JsonProperty("totalRecordsProcessed") long totalRecordsProcessed,
            @JsonProperty("successCount") long successCount,
            @JsonProperty("failureCount") long failureCount) {

        this.totalRecordsProcessed = totalRecordsProcessed;
        this.successCount = successCount;
        this.failureCount = failureCount;
    }

    public long getTotalRecordsProcessed() {
        return totalRecordsProcessed;
    }

    public long getSuccessCount() {
        return successCount;
    }

    public long getFailureCount() {
        return failureCount;
    }
}
