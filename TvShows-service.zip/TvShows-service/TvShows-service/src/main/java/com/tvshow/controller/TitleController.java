package com.tvshow.controller;

import com.tvshow.domain.Title;
import com.tvshow.exception.NotFoundException;
import com.tvshow.repository.TitleRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/titles")
public class TitleController {
    private final TitleRepository repo;
    public TitleController(TitleRepository repo){this.repo=repo;}

    @GetMapping("/{id}")
    public Mono<Title> getById(@PathVariable("id") String id){
        return repo.findById(UUID.fromString(id))
                .filter(Title::getActive)
                .switchIfEmpty(Mono.error(new NotFoundException("Title not found")));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Mono<Title> create(@RequestBody Title title){
        return repo.save(title);
    }


    @PutMapping("/{id}")
    public Mono<Title> update(@PathVariable String id, @RequestBody Title title){
        return repo.findById(UUID.fromString(id))
                .switchIfEmpty(Mono.error(new NotFoundException("Title not found")))
                .flatMap(existing -> {

                    // Update all fields you want to allow updating
                    existing.setType(title.getType());
                    existing.setTitle(title.getTitle());
                    existing.setDirector(title.getDirector());
                    existing.setCast(title.getCast());
                    existing.setCountry(title.getCountry());
                    existing.setDateAdded(title.getDateAdded());
                    existing.setReleaseYear(title.getReleaseYear());
                    existing.setRating(title.getRating());
                    existing.setDuration(title.getDuration());
                    existing.setListedIn(title.getListedIn());
                    existing.setDescription(title.getDescription());

                    return repo.save(existing);
                });
    }


    @DeleteMapping("/{id}")
    public Mono<ResponseEntity<Map<String, Object>>> softDelete(@PathVariable String id) {

        UUID uuid;

        try {
            uuid = UUID.fromString(id);
        } catch (IllegalArgumentException e) {
            // Invalid UUID format
            Map<String, Object> error = new HashMap<>();
            error.put("error", "Invalid ID format");
            return Mono.just(ResponseEntity.badRequest().body(error));
        }

        return repo.findById(uuid)
                .flatMap(t -> {
                    t.setActive(false);
                    return repo.save(t)
                            .map(saved -> {
                                Map<String, Object> response = new HashMap<>();
                                response.put("show_id", saved.getShowId());
                                response.put("message", "Title soft-deleted successfully");
                                return ResponseEntity.ok(response);
                            });
                })
                .switchIfEmpty(
                        Mono.fromSupplier(() -> {
                            Map<String, Object> error = new HashMap<>();
                            error.put("error", "ID does not exist");
                            return ResponseEntity.status(404).body(error);
                        })
                );
    }


    @GetMapping
    public Flux<Title> search(@RequestParam(required = false) Integer year,
                              @RequestParam(required = false) String rating){
        if(year!=null && rating!=null){
            return repo.findByReleaseYearAndRatingAndActiveTrue(year, rating);
        }
        return repo.findAll().filter(Title::getActive);
    }
}
