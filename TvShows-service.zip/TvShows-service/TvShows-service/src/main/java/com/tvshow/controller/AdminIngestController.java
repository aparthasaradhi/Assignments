package com.tvshow.controller;

import com.tvshow.dto.IngestSummaryDto;
import com.tvshow.service.IngestService;
import org.springframework.http.MediaType;
import org.springframework.http.HttpStatus;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;
import org.springframework.core.io.buffer.DataBufferUtils;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

@RestController
@RequestMapping("/api/v1/admin")
public class AdminIngestController {

    private final IngestService ingestService;

    public AdminIngestController(IngestService ingestService) {
        this.ingestService = ingestService;
    }
    @PostMapping(path = "/ingest", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Mono<IngestSummaryDto> ingest(@RequestPart("file") FilePart filePart) {

        return filePart.content()
                .map(dataBuffer -> {
                    byte[] bytes = new byte[dataBuffer.readableByteCount()];
                    dataBuffer.read(bytes);
                    DataBufferUtils.release(dataBuffer);
                    return bytes;
                })
                .reduce(this::concat)
                .flatMap(bytes -> {
                    InputStream inputStream = new ByteArrayInputStream(bytes);
                    return ingestService.ingest(inputStream);
                })
                .flatMap(summary -> {
                    // If any record failed → return 400
                    if (summary.getFailureCount() > 0) {
                        return Mono.error(new ResponseStatusException(
                                HttpStatus.BAD_REQUEST,
                                "Malformed CSV: " + summary.getFailureCount() + " record(s) failed"
                        ));
                    }
                    return Mono.just(summary);
                })
                .onErrorResume(ex -> {
                    if (ex instanceof IllegalArgumentException ||
                            ex instanceof RuntimeException) {
                        return Mono.error(
                                new ResponseStatusException(
                                        HttpStatus.BAD_REQUEST,
                                        "Invalid CSV format or data types",
                                        ex
                                )
                        );
                    }
                    return Mono.error(ex);
                });
    }


    private byte[] concat(byte[] a, byte[] b) {
        byte[] r = new byte[a.length + b.length];
        System.arraycopy(a, 0, r, 0, a.length);
        System.arraycopy(b, 0, r, a.length, b.length);
        return r;
    }
}
