package com.tvshow.dto;

public class WatchlistRequest {
    private String showId;
    private String name;

    public String getShowId(){return showId;}
    public void setShowId(String s){this.showId=s;}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
