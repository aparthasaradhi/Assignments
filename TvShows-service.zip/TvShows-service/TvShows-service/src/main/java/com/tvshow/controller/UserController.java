package com.tvshow.controller;

import com.tvshow.domain.Title;
import com.tvshow.domain.User;
import com.tvshow.dto.WatchlistRequest;
import com.tvshow.repository.TitleRepository;
import com.tvshow.repository.UserRepository;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/users")
public class UserController {
    private final UserRepository userRepo;
    private final TitleRepository titleRepo;
    public UserController(UserRepository u, TitleRepository t){this.userRepo=u; this.titleRepo=t;}

    @PostMapping("/{userId}/watchlist")
    public Mono<User> addToWatchlist(@PathVariable String userId, @RequestBody WatchlistRequest req) {
        return titleRepo.existsByShowId(UUID.fromString(req.getShowId()))
                .flatMap(exists -> {
                    if (!exists)
                        return Mono.error(new ResponseStatusException(HttpStatus.NOT_FOUND, "Title does not exist"));

                    return userRepo.findById(userId)
                            .defaultIfEmpty(new User(userId, req.getName() != null ? req.getName() : "anonymous"))
                            .flatMap(u -> {

                                if (u.getName() == null || u.getName().equals("anonymous")) {
                                    u.setName(req.getName());
                                }

                                if (!u.getWatchlist().contains(req.getShowId())) {
                                    u.getWatchlist().add(req.getShowId());
                                }

                                return userRepo.save(u);
                            });
                });
    }
    @GetMapping("/{userId}/watchlist")
    public Flux<Title> getWatchlist(@PathVariable String userId) {

        return userRepo.findById(userId)
                .flatMapMany(user -> Flux.fromIterable(user.getWatchlist()))
                .map(UUID::fromString)
                .flatMap(titleRepo::findByShowId)
                .filter(t -> Boolean.TRUE.equals(t.getActive()));
    }

}
