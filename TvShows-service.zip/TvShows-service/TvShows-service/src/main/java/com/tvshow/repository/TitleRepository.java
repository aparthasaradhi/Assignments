package com.tvshow.repository;

import com.tvshow.domain.Title;
import org.springframework.data.domain.Pageable;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.UUID;
public interface TitleRepository
        extends R2dbcRepository<Title, UUID> {

    Mono<Title> findByShowId(UUID showId);

    Flux<Title> findByReleaseYearAndRatingAndActiveTrue(Integer releaseYear, String rating);
    Flux<Title> findByActiveTrue(Pageable pageable);

    Mono<Boolean> existsByShowId(UUID showId);
}

