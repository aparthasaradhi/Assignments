package com.tvshow.service;

import com.tvshow.domain.Title;
import com.tvshow.dto.IngestSummaryDto;
import com.tvshow.repository.TitleRepository;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;

import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class IngestService {

    private final TitleRepository titleRepository;

    public IngestService(TitleRepository repo){
        this.titleRepository = repo;
    }

    public Mono<IngestSummaryDto> ingest(InputStream is) {

        return Mono.fromCallable(() -> new CSVReader(new InputStreamReader(is, StandardCharsets.UTF_8)))
                .subscribeOn(Schedulers.boundedElastic())
                .flatMapMany(reader -> {
                    try {
                        return Flux.fromStream(reader.readAll().stream());
                    } catch (IOException | CsvException e) {
                        throw new RuntimeException(e);
                    }
                })
                .skip(1) // skip header
                .flatMap(cols -> {

                    if (cols.length < 12) {
                        System.out.println("⚠️ INVALID ROW: " + Arrays.toString(cols));
                        return Mono.just(false);
                    }

                    Title t = new Title();

                    try {
                        t.setShowId(UUID.randomUUID());
                        t.setType(cols[1].trim());
                        t.setTitle(cols[2].trim());
                        t.setDirector(cols[3].trim());

                        // cast (store as comma-separated string)
                        if (!cols[4].isBlank()) {
                            t.setCast(Arrays.stream(cols[4].split(","))
                                    .map(String::trim)
                                    .collect(Collectors.joining(",")));
                        }

                        t.setCountry(cols[5].trim());
                        t.setDateAdded(cols[6].trim());

                        if (!cols[7].isBlank()) {
                            try {
                                t.setReleaseYear(Integer.parseInt(cols[7].trim()));
                            } catch (Exception ignored) {
                                t.setReleaseYear(null);
                            }
                        }

                        t.setRating(cols[8].trim());
                        t.setDuration(cols[9].trim());

                        t.setListedIn(Arrays.stream(cols[10].split(","))
                                .map(String::trim)
                                .collect(Collectors.joining(",")));

                        t.setDescription(cols[11].trim());

                    } catch (Exception e) {
                        System.out.println("❌ PARSE ERROR: " + Arrays.toString(cols));
                        e.printStackTrace();
                        return Mono.just(false);
                    }

                    // 🔥🔥🔥 KEY FIX — FORCE INSERT (avoid update error)
                    t.setShowId(null);

                    return titleRepository.save(t)
                            .map(saved -> true)
                            .onErrorResume(err -> {
                                System.out.println("❌ DB ERROR: " + Arrays.toString(cols));
                                err.printStackTrace();
                                return Mono.just(false);
                            });

                })
                .collectList()
                .map(list -> new IngestSummaryDto(
                        list.size(),
                        list.stream().filter(b -> b).count(),
                        list.stream().filter(b -> !b).count()
                ));
    }
}
