package com.tvshow.service;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class AnalyticsService {

    @Scheduled(cron = "${fluxflix.analytics.cron:0 0/5 * * * *}")
    public void runAnalytics(){
        System.out.println("[Analytics] scheduled job triggered");
    }
}
