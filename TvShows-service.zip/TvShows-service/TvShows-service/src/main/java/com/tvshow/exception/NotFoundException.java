package com.tvshow.exception;

public class NotFoundException extends RuntimeException {
    public NotFoundException(String msg){super(msg);}
}
