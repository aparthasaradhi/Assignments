package com.tvshow.controller;

import com.tvshow.domain.Title;
import com.tvshow.repository.TitleRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@WebFluxTest(TitleController.class)
class TitleControllerTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockBean
    private TitleRepository repo;

    private Title sampleTitle(UUID id, boolean active) {
        Title t = new Title();
        t.setShowId(id);
        t.setActive(active);
        t.setTitle("Sample Title");
        t.setType("Movie");
        t.setDirector("Director");
        t.setRating("PG");
        t.setReleaseYear(2020);
        return t;
    }

    /* ========================= GET BY ID ========================= */

    @Test
    void getById_success() {
        UUID id = UUID.randomUUID();
        Title title = sampleTitle(id, true);

        when(repo.findById(id)).thenReturn(Mono.just(title));

        webTestClient.get()
                .uri("/api/v1/titles/{id}", id.toString())
                .exchange()
                .expectStatus().isOk()
                .expectBody(Title.class)
                .value(t -> {
                    assert t.getShowId().equals(id);
                    assert t.getActive();
                });
    }

    @Test
    void getById_notFound_whenInactive() {
        UUID id = UUID.randomUUID();
        Title title = sampleTitle(id, false);

        when(repo.findById(id)).thenReturn(Mono.just(title));

        webTestClient.get()
                .uri("/api/v1/titles/{id}", id.toString())
                .exchange()
                .expectStatus().isNotFound();
    }

    @Test
    void getById_notFound_whenMissing() {
        UUID id = UUID.randomUUID();

        when(repo.findById(id)).thenReturn(Mono.empty());

        webTestClient.get()
                .uri("/api/v1/titles/{id}", id.toString())
                .exchange()
                .expectStatus().isNotFound();
    }

    /* ========================= CREATE ========================= */

    @Test
    void create_title() {
        UUID id = UUID.randomUUID();
        Title title = sampleTitle(id, true);

        when(repo.save(any(Title.class))).thenReturn(Mono.just(title));

        webTestClient.post()
                .uri("/api/v1/titles")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(title)
                .exchange()
                .expectStatus().isCreated()
                .expectBody(Title.class)
                .value(t -> {
                    assertThat(t.getShowId()).isEqualTo(id);
                });

    }

    /* ========================= UPDATE ========================= */

    @Test
    void update_success() {
        UUID id = UUID.randomUUID();
        Title existing = sampleTitle(id, true);
        Title updated = sampleTitle(id, true);
        updated.setTitle("Updated Title");

        when(repo.findById(id)).thenReturn(Mono.just(existing));
        when(repo.save(any(Title.class))).thenReturn(Mono.just(updated));

        webTestClient.put()
                .uri("/api/v1/titles/{id}", id)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(updated)
                .exchange()
                .expectStatus().isOk()
                .expectBody(Title.class)
                .value(t -> {
                    assertThat(t.getTitle()).isEqualTo("Updated Title");
                });
    }

    @Test
    void update_notFound() {
        UUID id = UUID.randomUUID();

        when(repo.findById(id)).thenReturn(Mono.empty());

        webTestClient.put()
                .uri("/api/v1/titles/{id}", id)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(new Title())
                .exchange()
                .expectStatus().isNotFound();
    }

    /* ========================= DELETE ========================= */

    @Test
    void softDelete_success() {
        UUID id = UUID.randomUUID();
        Title title = sampleTitle(id, true);

        when(repo.findById(id)).thenReturn(Mono.just(title));
        when(repo.save(any(Title.class))).thenReturn(Mono.just(title));

        webTestClient.delete()
                .uri("/api/v1/titles/{id}", id)
                .exchange()
                .expectStatus().isOk()
                .expectBody(Map.class)
                .value(body -> {
                    assert body.get("message").equals("Title soft-deleted successfully");
                });
    }

    @Test
    void softDelete_invalidUUID() {
        webTestClient.delete()
                .uri("/api/v1/titles/invalid-uuid")
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody(Map.class)
                .value(body -> {
                    assertThat(body.get("error")).isEqualTo("Invalid ID format");
                });

    }

    @Test
    void softDelete_idDoesNotExist() {
        UUID id = UUID.randomUUID();

        when(repo.findById(id)).thenReturn(Mono.empty());

        webTestClient.delete()
                .uri("/api/v1/titles/{id}", id)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody(Map.class)
                .value(body -> {
                    assertThat(body.get("error")).isEqualTo("ID does not exist");
                });

    }

    /* ========================= SEARCH ========================= */

    @Test
    void search_byYearAndRating() {
        Title title = sampleTitle(UUID.randomUUID(), true);

        when(repo.findByReleaseYearAndRatingAndActiveTrue(2020, "PG"))
                .thenReturn(Flux.just(title));

        webTestClient.get()
                .uri(uriBuilder ->
                        uriBuilder.path("/api/v1/titles")
                                .queryParam("year", 2020)
                                .queryParam("rating", "PG")
                                .build())
                .exchange()
                .expectStatus().isOk()
                .expectBodyList(Title.class)
                .hasSize(1);
    }

    @Test
    void search_allActive() {
        Title active = sampleTitle(UUID.randomUUID(), true);
        Title inactive = sampleTitle(UUID.randomUUID(), false);

        when(repo.findAll()).thenReturn(Flux.just(active, inactive));

        webTestClient.get()
                .uri("/api/v1/titles")
                .exchange()
                .expectStatus().isOk()
                .expectBodyList(Title.class)
                .hasSize(1); // inactive filtered out
    }
}
