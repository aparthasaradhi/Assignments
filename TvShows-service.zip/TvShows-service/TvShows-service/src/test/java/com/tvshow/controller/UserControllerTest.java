package com.tvshow.controller;

import com.tvshow.domain.Title;
import com.tvshow.domain.User;
import com.tvshow.dto.WatchlistRequest;
import com.tvshow.repository.TitleRepository;
import com.tvshow.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@WebFluxTest(UserController.class)
class UserControllerTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockBean
    private UserRepository userRepo;

    @MockBean
    private TitleRepository titleRepo;

    /* ========================= ADD TO WATCHLIST ========================= */
    @Test
    void addToWatchlist_existingUser_success() {
        String userId = "user-1";
        String showId = UUID.randomUUID().toString();  // String for request

        WatchlistRequest req = new WatchlistRequest();
        req.setShowId(showId);
        req.setName("John");

        User user = new User(userId, "John");
        user.getWatchlist().add(showId);

        // ✅ Fix: convert to UUID
        when(titleRepo.existsByShowId(any(UUID.class))).thenReturn(Mono.just(true));
        when(userRepo.findById(userId)).thenReturn(Mono.just(user));
        when(userRepo.save(any(User.class))).thenReturn(Mono.just(user));

        webTestClient.post()
                .uri("/api/v1/users/{id}/watchlist", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(req)
                .exchange()
                .expectStatus().isOk()
                .expectBody(User.class)
                .value(u -> {
                    assertThat(u.getWatchlist()).contains(showId);
                    assertThat(u.getName()).isEqualTo("John");
                });
    }

    @Test
    void addToWatchlist_newUser_created() {
        String userId = "user-2";
        String showId = UUID.randomUUID().toString(); // String for request

        WatchlistRequest req = new WatchlistRequest();
        req.setShowId(showId);
        req.setName("Alice");

        User saved = new User(userId, "Alice");
        saved.getWatchlist().add(showId);

        // ✅ Fix type mismatch by converting String → UUID or using matcher
        when(titleRepo.existsByShowId(any(UUID.class))).thenReturn(Mono.just(true));
        when(userRepo.findById(userId)).thenReturn(Mono.empty());
        when(userRepo.save(any(User.class))).thenReturn(Mono.just(saved));

        webTestClient.post()
                .uri("/api/v1/users/{id}/watchlist", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(req)
                .exchange()
                .expectStatus().isOk()
                .expectBody(User.class)
                .value(u -> {
                    assertThat(u.getWatchlist()).hasSize(1);
                    assertThat(u.getName()).isEqualTo("Alice");
                });
    }

    @Test
    void addToWatchlist_titleDoesNotExist() {
        String userId = "user-3";
        String showId = UUID.randomUUID().toString();

        WatchlistRequest req = new WatchlistRequest();
        req.setShowId(showId);

        // ✅ Fix type mismatch by converting String → UUID or using matcher
        when(titleRepo.existsByShowId(any(UUID.class))).thenReturn(Mono.just(false));

        webTestClient.post()
                .uri("/api/v1/users/{id}/watchlist", userId)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(req)
                .exchange()
                .expectStatus().isBadRequest(); // IllegalArgumentException → 400
    }


    /* ========================= GET WATCHLIST ========================= */

    @Test
    void getWatchlist_success_onlyActiveTitlesReturned() {
        String userId = "user-4";
        String activeId = UUID.randomUUID().toString();
        String inactiveId = UUID.randomUUID().toString();

        User user = new User(userId, "Bob");
        user.setWatchlist(List.of(activeId, inactiveId));

        Title activeTitle = new Title();
        activeTitle.setShowId(UUID.fromString(activeId));
        activeTitle.setActive(true);

        Title inactiveTitle = new Title();
        inactiveTitle.setShowId(UUID.fromString(inactiveId));
        inactiveTitle.setActive(false);

        when(userRepo.findById(userId)).thenReturn(Mono.just(user));
        when(titleRepo.findById(UUID.fromString(activeId))).thenReturn(Mono.just(activeTitle));
        when(titleRepo.findById(UUID.fromString(inactiveId))).thenReturn(Mono.just(inactiveTitle));

        webTestClient.get()
                .uri("/api/v1/users/{id}/watchlist", userId)
                .exchange()
                .expectStatus().isOk()
                .expectBodyList(Title.class)
                .hasSize(1)
                .value(list -> {
                    assertThat(list.get(0).getShowId())
                            .isEqualTo(UUID.fromString(activeId));
                });
    }

    @Test
    void getWatchlist_userNotFound_returnsEmpty() {
        when(userRepo.findById("missing")).thenReturn(Mono.empty());

        webTestClient.get()
                .uri("/api/v1/users/missing/watchlist")
                .exchange()
                .expectStatus().isOk()
                .expectBodyList(Title.class)
                .hasSize(0);
    }
}
