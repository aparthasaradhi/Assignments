package com.tvshow.controller;

import com.tvshow.dto.IngestSummaryDto;
import com.tvshow.service.IngestService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.MediaType;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

import java.io.InputStream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@WebFluxTest(AdminIngestController.class)
class AdminIngestControllerTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockBean
    private IngestService ingestService;

    @Test
    void ingest_shouldUploadFileAndReturnSummary() {

        byte[] fileContent = "test,data".getBytes();

        IngestSummaryDto responseDto =
                new IngestSummaryDto(3L, 3L, 0L);

        when(ingestService.ingest(any(InputStream.class)))
                .thenReturn(Mono.just(responseDto));

        MultipartBodyBuilder bodyBuilder = new MultipartBodyBuilder();
        bodyBuilder.part("file",
                new ByteArrayResource(fileContent) {
                    @Override
                    public String getFilename() {
                        return "test.csv";
                    }
                });

        webTestClient.post()
                .uri("/api/v1/admin/ingest")
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .bodyValue(bodyBuilder.build())
                .exchange()
                .expectStatus().isOk()
                .expectBody(IngestSummaryDto.class)
                .value(dto -> {
                    assertThat(dto.getTotalRecordsProcessed()).isEqualTo(3L);
                    assertThat(dto.getSuccessCount()).isEqualTo(3L);
                    assertThat(dto.getFailureCount()).isEqualTo(0L);
                });
    }

}
