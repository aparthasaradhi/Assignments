package com.tvshow.domain;

import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

class TitleTest {

    @Test
    void shouldSetAndGetAllFields() {
        UUID id = UUID.randomUUID();

        Title title = new Title();
        title.setShowId(id);
        title.setType("Movie");
        title.setTitle("Inception");
        title.setDirector("Christopher Nolan");
        title.setCast("Leonardo DiCaprio,Joseph Gordon-Levitt");
        title.setCountry("USA");
        title.setDateAdded("2023-01-01");
        title.setReleaseYear(2010);
        title.setRating("PG-13");
        title.setDuration("148 min");
        title.setListedIn("Sci-Fi,Thriller");
        title.setDescription("A mind-bending thriller");

        assertThat(title.getShowId()).isEqualTo(id);
        assertThat(title.getType()).isEqualTo("Movie");
        assertThat(title.getTitle()).isEqualTo("Inception");
        assertThat(title.getDirector()).isEqualTo("Christopher Nolan");
        assertThat(title.getCast()).isEqualTo("Leonardo DiCaprio,Joseph Gordon-Levitt");
        assertThat(title.getCountry()).isEqualTo("USA");
        assertThat(title.getDateAdded()).isEqualTo("2023-01-01");
        assertThat(title.getReleaseYear()).isEqualTo(2010);
        assertThat(title.getRating()).isEqualTo("PG-13");
        assertThat(title.getDuration()).isEqualTo("148 min");
        assertThat(title.getListedIn()).isEqualTo("Sci-Fi,Thriller");
        assertThat(title.getDescription()).isEqualTo("A mind-bending thriller");
    }

    @Test
    void active_shouldBeTrueByDefault() {
        Title title = new Title();

        assertThat(title.getActive()).isTrue();
    }

    @Test
    void shouldAllowDeactivatingTitle() {
        Title title = new Title();

        title.setActive(false);

        assertThat(title.getActive()).isFalse();
    }
}
