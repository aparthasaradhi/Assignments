package com.tvshow.repository;

import com.tvshow.domain.Title;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.r2dbc.DataR2dbcTest;
import reactor.test.StepVerifier;

import java.util.List;
import java.util.UUID;

import static com.mongodb.internal.connection.tlschannel.util.Util.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

@DataR2dbcTest
class TitleRepositoryTest {

    @Autowired
    private TitleRepository titleRepository;

    @BeforeEach
    void cleanDb() {
        StepVerifier.create(titleRepository.deleteAll())
                .verifyComplete();
    }

    @Test
    void findByReleaseYearAndRatingAndActiveTrue_shouldReturnOnlyActive() {

        Title activeMatch = createTitle(2020, "PG", true);
        Title inactiveMatch = createTitle(2020, "PG", false);
        Title differentRating = createTitle(2020, "R", true);

        StepVerifier.create(
                        titleRepository.saveAll(
                                        List.of(activeMatch, inactiveMatch, differentRating)
                                )
                                .thenMany(
                                        titleRepository.findByReleaseYearAndRatingAndActiveTrue(2020, "PG")
                                )
                                .collectList()
                )
                .assertNext(list -> {
                    assertEquals(1, list.size());
                    Title t = list.get(0);
                    assertEquals(2020, t.getReleaseYear());
                    assertEquals("PG", t.getRating());
                    assertTrue(t.getActive());
                })
                .verifyComplete();
    }

    private Title createTitle(int year, String rating, boolean active) {
        Title t = new Title();
        // ❌ DO NOT set ID
        t.setReleaseYear(year);
        t.setRating(rating);
        t.setActive(active);
        return t;
    }



    /* ================= findByActiveTrue(Pageable) ================= */

    @Test
    void findByReleaseYearAndRatingAndActiveTrue_shouldReturnTwoTitles() {

        Title t1 = new Title();
        t1.setShowId(null); // 🔥 REQUIRED
        t1.setTitle("Movie 1");
        t1.setReleaseYear(2020);
        t1.setRating("PG");
        t1.setActive(true);

        Title t2 = new Title();
        t2.setShowId(null); // 🔥 REQUIRED
        t2.setTitle("Movie 2");
        t2.setReleaseYear(2020);
        t2.setRating("PG");
        t2.setActive(true);

        StepVerifier.create(
                        titleRepository.saveAll(List.of(t1, t2))
                                .thenMany(
                                        titleRepository.findByReleaseYearAndRatingAndActiveTrue(2020, "PG")
                                )
                )
                .expectNextCount(2)
                .verifyComplete();
    }


    /* ================= existsByShowId ================= */
    @Test
    void existsByShowId_shouldReturnTrueWhenExists() {

        Title t = new Title();
        t.setShowId(null); // let R2DBC generate a UUID
        t.setTitle("Test");
        t.setActive(true);

        StepVerifier.create(
                        titleRepository.save(t)
                                .flatMap(saved ->
                                        // ✅ pass UUID directly
                                        titleRepository.existsByShowId(saved.getShowId())
                                )
                )
                .expectNext(true)
                .verifyComplete();
    }

    @Test
    void existsByShowId_shouldReturnFalseWhenMissing() {

        StepVerifier.create(
                        titleRepository.existsByShowId(UUID.randomUUID()) // ✅ pass UUID directly
                )
                .expectNext(false)
                .verifyComplete();
    }

}
