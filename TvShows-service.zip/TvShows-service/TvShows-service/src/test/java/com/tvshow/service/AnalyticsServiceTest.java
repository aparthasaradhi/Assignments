package com.tvshow.service;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThatNoException;

class AnalyticsServiceTest {

    @Test
    void runAnalytics_shouldExecuteWithoutException() {
        AnalyticsService service = new AnalyticsService();

        assertThatNoException().isThrownBy(service::runAnalytics);
    }
}
