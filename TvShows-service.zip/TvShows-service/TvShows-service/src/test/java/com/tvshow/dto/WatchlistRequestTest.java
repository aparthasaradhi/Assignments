package com.tvshow.dto;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class WatchlistRequestTest {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    void settersAndGetters_shouldWorkCorrectly() {

        WatchlistRequest request = new WatchlistRequest();
        request.setShowId("show-123");
        request.setName("Breaking Bad");

        assertEquals("show-123", request.getShowId());
        assertEquals("Breaking Bad", request.getName());
    }

    @Test
    void shouldSerializeToJsonCorrectly() throws Exception {

        WatchlistRequest request = new WatchlistRequest();
        request.setShowId("show-456");
        request.setName("Stranger Things");

        String json = objectMapper.writeValueAsString(request);

        assertTrue(json.contains("\"showId\":\"show-456\""));
        assertTrue(json.contains("\"name\":\"Stranger Things\""));
    }

    @Test
    void shouldDeserializeFromJsonCorrectly() throws Exception {

        String json = """
                {
                  "showId": "show-789",
                  "name": "Dark"
                }
                """;

        WatchlistRequest request =
                objectMapper.readValue(json, WatchlistRequest.class);

        assertEquals("show-789", request.getShowId());
        assertEquals("Dark", request.getName());
    }
}
