package com.tvshow.domain;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class UserTest {

    @Test
    void defaultConstructor_shouldInitializeEmptyWatchlist() {
        User user = new User();

        assertThat(user.getWatchlist()).isNotNull();
        assertThat(user.getWatchlist()).isEmpty();
    }

    @Test
    void parameterizedConstructor_shouldSetIdAndName() {
        User user = new User("user-1", "John");

        assertThat(user.getId()).isEqualTo("user-1");
        assertThat(user.getName()).isEqualTo("John");
    }

    @Test
    void shouldAllowSettingAndGettingId() {
        User user = new User();
        user.setId("user-2");

        assertThat(user.getId()).isEqualTo("user-2");
    }

    @Test
    void shouldAllowSettingAndGettingName() {
        User user = new User();
        user.setName("Alice");

        assertThat(user.getName()).isEqualTo("Alice");
    }

    @Test
    void shouldAllowUpdatingWatchlist() {
        User user = new User();

        user.getWatchlist().add("show-1");
        user.getWatchlist().add("show-2");

        assertThat(user.getWatchlist())
                .hasSize(2)
                .containsExactly("show-1", "show-2");
    }

    @Test
    void setWatchlist_shouldReplaceExistingList() {
        User user = new User();

        user.setWatchlist(List.of("show-3", "show-4"));

        assertThat(user.getWatchlist())
                .containsExactly("show-3", "show-4");
    }
}
