package com.tvshow.exception;

import com.tvshow.controller.TitleController;
import com.tvshow.domain.Title;
import com.tvshow.repository.TitleRepository;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.Map;
import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

@WebFluxTest(controllers = TitleController.class)
@Import(GlobalErrorHandler.class)
class TitleControllerTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockBean
    private TitleRepository titleRepository;

    /* ---------------- GET BY ID ---------------- */

    @Test
    void getById_shouldReturnActiveTitle() {
        UUID id = UUID.randomUUID();

        Title title = new Title();
        title.setShowId(id);
        title.setActive(true);

        Mockito.when(titleRepository.findById(id))
                .thenReturn(Mono.just(title));

        webTestClient.get()
                .uri("/api/v1/titles/{id}", id)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.showId").isEqualTo(id.toString());
    }

    @Test
    void getById_shouldReturn404_whenInactive() {
        UUID id = UUID.randomUUID();

        Title title = new Title();
        title.setShowId(id);
        title.setActive(false);

        Mockito.when(titleRepository.findById(id))
                .thenReturn(Mono.just(title));

        webTestClient.get()
                .uri("/api/v1/titles/{id}", id)
                .exchange()
                .expectStatus().isNotFound();
    }

    @Test
    void getById_shouldReturn404_whenNotFound() {
        UUID id = UUID.randomUUID();

        Mockito.when(titleRepository.findById(id))
                .thenReturn(Mono.empty());

        webTestClient.get()
                .uri("/api/v1/titles/{id}", id)
                .exchange()
                .expectStatus().isNotFound();
    }

    /* ---------------- CREATE ---------------- */

    @Test
    void create_shouldReturn201() {

        Title saved = new Title();
        saved.setShowId(UUID.randomUUID());

        Mockito.when(titleRepository.save(any(Title.class)))
                .thenReturn(Mono.just(saved));

        webTestClient.post()
                .uri("/api/v1/titles")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"title\":\"Test Movie\"}")
                .exchange()
                .expectStatus().isCreated()
                .expectBody()
                .jsonPath("$.showId").exists();
    }

    /* ---------------- UPDATE ---------------- */

    @Test
    void update_shouldReturnUpdatedTitle() {
        UUID id = UUID.randomUUID();

        Title existing = new Title();
        existing.setShowId(id);

        Mockito.when(titleRepository.findById(id))
                .thenReturn(Mono.just(existing));

        Mockito.when(titleRepository.save(any(Title.class)))
                .thenAnswer(inv -> Mono.just(inv.getArgument(0)));

        webTestClient.put()
                .uri("/api/v1/titles/{id}", id)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"title\":\"Updated\"}")
                .exchange()
                .expectStatus().isOk();
    }

    @Test
    void update_shouldReturn404_whenNotFound() {
        UUID id = UUID.randomUUID();

        Mockito.when(titleRepository.findById(id))
                .thenReturn(Mono.empty());

        webTestClient.put()
                .uri("/api/v1/titles/{id}", id)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue("{\"title\":\"Updated\"}")
                .exchange()
                .expectStatus().isNotFound();
    }

    /* ---------------- DELETE (SOFT) ---------------- */

    @Test
    void delete_shouldSoftDeleteAndReturn200() {
        UUID id = UUID.randomUUID();

        Title title = new Title();
        title.setShowId(id);
        title.setActive(true);

        Mockito.when(titleRepository.findById(id))
                .thenReturn(Mono.just(title));

        Mockito.when(titleRepository.save(any(Title.class)))
                .thenReturn(Mono.just(title));

        webTestClient.delete()
                .uri("/api/v1/titles/{id}", id)
                .exchange()
                .expectStatus().isOk()
                .expectBody()
                .jsonPath("$.message").isEqualTo("Title soft-deleted successfully");
    }

    @Test
    void delete_shouldReturn400_forInvalidUUID() {

        webTestClient.delete()
                .uri("/api/v1/titles/invalid-id")
                .exchange()
                .expectStatus().isBadRequest()
                .expectBody()
                .jsonPath("$.error").isEqualTo("Invalid ID format");
    }

    @Test
    void delete_shouldReturn404_whenIdDoesNotExist() {
        UUID id = UUID.randomUUID();

        Mockito.when(titleRepository.findById(id))
                .thenReturn(Mono.empty());

        webTestClient.delete()
                .uri("/api/v1/titles/{id}", id)
                .exchange()
                .expectStatus().isNotFound()
                .expectBody()
                .jsonPath("$.error").isEqualTo("ID does not exist");
    }

    /* ---------------- SEARCH ---------------- */

    @Test
    void search_shouldReturnActiveTitles() {

        Title t1 = new Title();
        t1.setActive(true);

        Title t2 = new Title();
        t2.setActive(false);

        Mockito.when(titleRepository.findAll())
                .thenReturn(Flux.just(t1, t2));

        webTestClient.get()
                .uri("/api/v1/titles")
                .exchange()
                .expectStatus().isOk()
                .expectBodyList(Title.class)
                .hasSize(1);
    }

    @Test
    void search_withYearAndRating_shouldUseFilteredRepoMethod() {

        Title title = new Title();
        title.setActive(true);

        Mockito.when(
                titleRepository.findByReleaseYearAndRatingAndActiveTrue(2020, "PG")
        ).thenReturn(Flux.just(title));

        webTestClient.get()
                .uri(uriBuilder -> uriBuilder
                        .path("/api/v1/titles")
                        .queryParam("year", 2020)
                        .queryParam("rating", "PG")
                        .build()
                )
                .exchange()
                .expectStatus().isOk()
                .expectBodyList(Title.class)
                .hasSize(1);
    }
}
