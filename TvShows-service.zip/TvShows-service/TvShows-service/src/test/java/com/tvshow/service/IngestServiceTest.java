package com.tvshow.service;

import com.tvshow.domain.Title;
import com.tvshow.repository.TitleRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class IngestServiceTest {

    @Mock
    private TitleRepository titleRepository;

    @InjectMocks
    private IngestService ingestService;

    /* ========================= SUCCESS CASE ========================= */

    @Test
    void ingest_validCsv_shouldReturnCorrectSummary() {
        // CSV with header + 2 valid rows
        String csv =
                "show_id,type,title,director,cast,country,date_added,release_year,rating,duration,listed_in,description\n" +
                        "s1,Movie,Title1,Dir1,A,B,2020,2020,PG,90 min,Drama,Desc1\n" +
                        "s2,Movie,Title2,Dir2,C,D,2021,2021,PG,100 min,Comedy,Desc2\n";

        InputStream is = new ByteArrayInputStream(csv.getBytes(StandardCharsets.UTF_8));

        when(titleRepository.save(any(Title.class)))
                .thenReturn(Mono.just(new Title()));

        StepVerifier.create(ingestService.ingest(is))
                .assertNext(summary -> {
                    assertThat(summary.getTotalRecordsProcessed()).isEqualTo(2);
                    assertThat(summary.getSuccessCount()).isEqualTo(2);
                    assertThat(summary.getFailureCount()).isEqualTo(0);
                })
                .verifyComplete();
    }

    /* ========================= INVALID ROW ========================= */

    @Test
    void ingest_invalidRow_shouldCountFailure() {
        // Second row has < 12 columns → invalid
        String csv =
                "show_id,type,title,director,cast,country,date_added,release_year,rating,duration,listed_in,description\n" +
                        "s1,Movie,Title1,Dir1,A,B,2020,2020,PG,90 min,Drama,Desc1\n" +
                        "INVALID,ROW\n";

        InputStream is = new ByteArrayInputStream(csv.getBytes(StandardCharsets.UTF_8));

        when(titleRepository.save(any(Title.class)))
                .thenReturn(Mono.just(new Title()));

        StepVerifier.create(ingestService.ingest(is))
                .assertNext(summary -> {
                    assertThat(summary.getTotalRecordsProcessed()).isEqualTo(2);
                    assertThat(summary.getSuccessCount()).isEqualTo(1);
                    assertThat(summary.getFailureCount()).isEqualTo(1);
                })
                .verifyComplete();
    }

    /* ========================= DB ERROR ========================= */

    @Test
    void ingest_dbError_shouldCountFailure() {
        String csv =
                "show_id,type,title,director,cast,country,date_added,release_year,rating,duration,listed_in,description\n" +
                        "s1,Movie,Title1,Dir1,A,B,2020,2020,PG,90 min,Drama,Desc1\n";

        InputStream is = new ByteArrayInputStream(csv.getBytes(StandardCharsets.UTF_8));

        when(titleRepository.save(any(Title.class)))
                .thenReturn(Mono.error(new RuntimeException("DB error")));

        StepVerifier.create(ingestService.ingest(is))
                .assertNext(summary -> {
                    assertThat(summary.getTotalRecordsProcessed()).isEqualTo(1);
                    assertThat(summary.getSuccessCount()).isEqualTo(0);
                    assertThat(summary.getFailureCount()).isEqualTo(1);
                })
                .verifyComplete();
    }
}
