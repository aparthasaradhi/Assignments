package com.tvshow.dto;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class IngestSummaryDtoTest {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    void constructorAndGetters_shouldWorkCorrectly() {

        IngestSummaryDto dto = new IngestSummaryDto(
                100L,
                80L,
                20L
        );

        assertEquals(100L, dto.getTotalRecordsProcessed());
        assertEquals(80L, dto.getSuccessCount());
        assertEquals(20L, dto.getFailureCount());
    }

    @Test
    void shouldSerializeToJsonCorrectly() throws Exception {

        IngestSummaryDto dto = new IngestSummaryDto(
                50L,
                45L,
                5L
        );

        String json = objectMapper.writeValueAsString(dto);

        assertTrue(json.contains("\"totalRecordsProcessed\":50"));
        assertTrue(json.contains("\"successCount\":45"));
        assertTrue(json.contains("\"failureCount\":5"));
    }

    @Test
    void shouldDeserializeFromJsonUsingJsonCreator() throws Exception {

        String json = """
                {
                  "totalRecordsProcessed": 200,
                  "successCount": 190,
                  "failureCount": 10
                }
                """;

        IngestSummaryDto dto = objectMapper.readValue(json, IngestSummaryDto.class);

        assertEquals(200L, dto.getTotalRecordsProcessed());
        assertEquals(190L, dto.getSuccessCount());
        assertEquals(10L, dto.getFailureCount());
    }
}
