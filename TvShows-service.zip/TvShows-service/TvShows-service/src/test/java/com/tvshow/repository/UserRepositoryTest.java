package com.tvshow.repository;

import com.tvshow.domain.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;
import reactor.test.StepVerifier;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DataMongoTest
class UserRepositoryTest {

    @Autowired
    private UserRepository userRepository;

    @BeforeEach
    void cleanDb() {
        StepVerifier.create(userRepository.deleteAll())
                .verifyComplete();
    }

    @Test
    void saveAndFindAll_shouldReturnUsers() {

        User user1 = new User();
        user1.setName("John");

        User user2 = new User();
        user2.setName("Mary");
        user2.setWatchlist(List.of("show1", "show2"));

        StepVerifier.create(
                        userRepository.saveAll(List.of(user1, user2))
                                .thenMany(userRepository.findAll())
                                .collectList()
                )
                .assertNext(users -> {
                    assertEquals(2, users.size());

                    User john = users.stream()
                            .filter(u -> "John".equals(u.getName()))
                            .findFirst()
                            .orElseThrow();

                    User mary = users.stream()
                            .filter(u -> "Mary".equals(u.getName()))
                            .findFirst()
                            .orElseThrow();

                    assertTrue(john.getWatchlist().isEmpty());
                    assertEquals(2, mary.getWatchlist().size());
                })
                .verifyComplete();
    }

    @Test
    void saveAndFindById_shouldReturnCorrectUser() {

        User user = new User();
        user.setName("Alice");
        user.setWatchlist(List.of("showA", "showB"));

        StepVerifier.create(
                        userRepository.save(user)
                                .flatMap(saved -> userRepository.findById(saved.getId()))
                )
                .assertNext(found -> {
                    assertNotNull(found.getId());
                    assertEquals("Alice", found.getName());
                    assertEquals(List.of("showA", "showB"), found.getWatchlist());
                })
                .verifyComplete();
    }

    @Test
    void updateWatchlist_shouldPersistChanges() {

        User user = new User();
        user.setName("Bob");

        StepVerifier.create(
                        userRepository.save(user)
                                .flatMap(saved -> {
                                    saved.getWatchlist().add("showX");
                                    saved.getWatchlist().add("showY");
                                    return userRepository.save(saved);
                                })
                                .flatMap(updated -> userRepository.findById(updated.getId()))
                )
                .assertNext(updated -> {
                    assertEquals("Bob", updated.getName());
                    assertEquals(2, updated.getWatchlist().size());
                    assertTrue(updated.getWatchlist().contains("showX"));
                })
                .verifyComplete();
    }
}
